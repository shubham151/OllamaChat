import initModelUI from "./model-ui.js";

export default function initHeaderUI() {
  const settingsBtn = document.getElementById("settings-btn");

  settingsBtn.addEventListener("click", () => {
    document.getElementById("settings-panel").classList.toggle("hidden");
  });

  const dropdownBtn = document.getElementById("model-display-btn");
  const dropdownMenu = document.getElementById("model-options");

  dropdownBtn.addEventListener("click", () => {
    dropdownMenu.classList.toggle("show");
  });

  initModelUI();
}
